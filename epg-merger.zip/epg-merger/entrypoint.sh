#!/usr/bin/env sh
set -e

INTERVAL_SECONDS=$(( ${MERGE_INTERVAL_HOURS:-6} * 3600 ))

echo "[entrypoint] Starte initialen Merge..."
python merge_epg.py --config sources.json --output epg/merged_epg.xml.gz || echo "[entrypoint] Initialer Merge fehlgeschlagen, HTTP-Server startet trotzdem."

echo "[entrypoint] Starte HTTP-Server auf Port ${SERVE_PORT:-8080} (serviert ./epg)..."
python -m http.server "${SERVE_PORT:-8080}" --directory epg &
SERVER_PID=$!

echo "[entrypoint] Merge-Loop laeuft alle ${MERGE_INTERVAL_HOURS:-6}h..."
while true; do
  sleep "$INTERVAL_SECONDS"
  echo "[entrypoint] $(date -u): Starte geplanten Merge..."
  python merge_epg.py --config sources.json --output epg/merged_epg.xml.gz || echo "[entrypoint] Merge-Durchlauf fehlgeschlagen, versuche es beim naechsten Intervall erneut."
done

wait "$SERVER_PID"
