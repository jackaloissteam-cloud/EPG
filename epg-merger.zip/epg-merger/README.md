# EPG-Merger für TiviMate

Führt mehrere XMLTV-EPG-Quellen (Europa, Ukraine, USA) zu **einer** validen,
komprimierten XMLTV-Datei zusammen und stellt sie über eine stabile URL bereit,
die du in TiviMate als EPG-Quelle einträgst.

## Wie es funktioniert

1. `merge_epg.py` lädt alle Quellen aus `sources.json` herunter (robust: eine
   kaputte Quelle bricht nichts ab, wird nur übersprungen und geloggt).
2. Kanäle werden anhand des normalisierten Anzeigenamens dedupliziert
   (z. B. "Das Erste HD", "DasErste", "Das Erste (DE)" → ein Kanal). Von
   mehreren Duplikaten gewinnt der Kanal mit den meisten Sendungen.
3. Sendungen werden pro Kanal auf `(Startzeit, Titel)` dedupliziert; bei
   Duplikaten gewinnt der inhaltlich reichhaltigere Eintrag (mehr Text in
   Beschreibung/Kategorie/etc.).
4. Alle Zeiten werden nach **UTC** normalisiert (`+0000`), damit es keine
   Zeitzonen-Konflikte zwischen Quellen gibt.
5. Ungültige Einträge (fehlender Titel, fehlende Startzeit, verwaiste
   Sendungen ohne bekannten Kanal) werden verworfen.
6. Ausgabe: `epg/merged_epg.xml.gz` (+ unkomprimierte `epg/merged_epg.xml`
   zum Debuggen) und `epg/merge.log`.

## Empfohlene Variante: GitHub Actions + `raw.githubusercontent.com`

**Das ist die einfachste, kostenlose Variante ohne eigenen Server.**

### Einrichtung (einmalig, ca. 5 Minuten)

1. Erstelle ein **neues, öffentliches** GitHub-Repository (z. B. `mein-epg`).
2. Lade alle Dateien aus diesem Projekt in das Repository hoch (per Web-UI
   "Add file → Upload files" oder `git push`):
   - `merge_epg.py`
   - `sources.json`
   - `requirements.txt`
   - `.github/workflows/merge-epg.yml`
   - (Dockerfile + entrypoint.sh nur nötig, wenn du Variante 2 unten nutzen willst)
3. Gehe im Repo auf den Tab **Actions** → falls gefragt, Workflows aktivieren.
4. Wähle links den Workflow **"Merge EPG"** und klicke **"Run workflow"**
   (manueller erster Lauf, dauert 1–3 Minuten).
5. Nach erfolgreichem Lauf liegt die Datei unter `epg/merged_epg.xml.gz`
   im Repo. Deine stabile URL lautet:

   ```
   https://raw.githubusercontent.com/<dein-github-name>/<repo-name>/main/epg/merged_epg.xml.gz
   ```

   Beispiel: `https://raw.githubusercontent.com/jackaloissteam-cloud/mein-epg/main/epg/merged_epg.xml.gz`

6. Fertig. Der Workflow läuft danach automatisch alle 6 Stunden
   (per `cron: "0 */6 * * *"` in der Workflow-Datei) und committed die
   aktualisierte Datei automatisch.

**Aktualisierungsintervall ändern:** In `.github/workflows/merge-epg.yml`
die `cron`-Zeile anpassen, z. B. `"0 3,9,15,21 * * *"` für 4× täglich.

**Cache-Hinweis:** `raw.githubusercontent.com` cached Antworten oft ca.
5 Minuten. TiviMate lädt die EPG typischerweise ohnehin nur alle paar Stunden
neu, das spielt also keine Rolle. Falls du sofortige Aktualisierung nach
einem manuellen Lauf brauchst, nutze alternativ diese CDN-URL (kein Caching-
Delay, gleiche Datei):

```
https://cdn.jsdelivr.net/gh/<dein-github-name>/<repo-name>@main/epg/merged_epg.xml.gz
```

### In TiviMate eintragen

1. TiviMate öffnen → **Settings → EPG → Add source** (bzw. "EPG-Quelle
   hinzufügen").
2. Als **Source type**: "XMLTV" wählen.
3. Als **URL** die obige `raw.githubusercontent.com`-URL (oder jsdelivr-URL)
   eintragen.
4. Speichern → TiviMate lädt und entpackt die `.xml.gz` automatisch.
5. Anschließend in den Kanaleinstellungen die TiviMate-Kanäle den `tvg-id`s
   aus der gemergten Datei zuordnen (wie bei jeder anderen XMLTV-Quelle auch).

## Alternative Hosting-Optionen (falls du sie brauchst)

| Option | Aufwand | Kosten | Wann sinnvoll |
|---|---|---|---|
| **GitHub Actions + raw.githubusercontent.com** (empfohlen) | sehr gering | kostenlos | Für die meisten Nutzer die beste Wahl |
| GitHub Pages (`gh-pages`-Branch) | gering | kostenlos | Wenn du eine "echte" Webserver-URL mit besserem Caching/CDN willst |
| Cloudflare Workers + R2 | mittel | kostenlos (Free Tier) | Wenn du volle Kontrolle über Caching/Header willst |
| Eigener VPS/Docker (siehe `Dockerfile`) | höher | VPS-Kosten | Wenn du bereits einen Server laufen hast oder maximale Kontrolle willst |

### Docker/VPS-Variante (optional, nur falls gewünscht)

Falls du einen eigenen Server/VPS hast:

```bash
docker build -t epg-merger .
docker run -d --name epg-merger \
  -p 8080:8080 \
  -e MERGE_INTERVAL_HOURS=6 \
  epg-merger
```

Die Datei ist danach erreichbar unter `http://<server-ip>:8080/merged_epg.xml.gz`.
Für eine stabile, öffentliche HTTPS-URL zusätzlich einen Reverse Proxy
(z. B. Caddy, nginx, oder Cloudflare Tunnel) davorschalten.

## Quellen anpassen

Bearbeite `sources.json`. Jede Quelle braucht `name` (eindeutig), `url` und
optional `priority` (höher = bevorzugt bei gleichnamigen Kanälen mit
ähnlicher Sendungsanzahl). Ich konnte nicht alle exakten Dateinamen der
weiteren Länder-Feeds auf `open-epg.com` und `free-epg.de` zuverlässig
verifizieren (die Datei-Listings dort ändern sich gelegentlich) — bitte
dort die aktuell verfügbaren Dateien prüfen:

- https://www.open-epg.com/
- https://free-epg.de/

und bei Bedarf weitere Einträge nach dem bestehenden Muster in
`sources.json` ergänzen. Der Merge-Prozess funktioniert mit beliebig vielen
zusätzlichen Quellen, ohne Codeänderung.

## Lokal testen

```bash
pip install -r requirements.txt
python merge_epg.py --config sources.json --output epg/merged_epg.xml.gz
```

Log-Ausgabe erscheint in der Konsole und in `epg/merge.log`. Bei Bedarf mit
`--no-plain` die zusätzliche unkomprimierte `.xml`-Datei weglassen.

## Troubleshooting

- **"Keine einzige Quelle konnte erfolgreich geladen werden"**: Alle URLs in
  `sources.json` sind aktuell nicht erreichbar (Provider down / URL geändert)
  → einzelne URLs im Browser prüfen und ggf. aktualisieren.
- **TiviMate zeigt keine neuen Daten**: Prüfe erst, ob die Datei unter der
  `raw.githubusercontent.com`-URL im Browser lädt und ein aktuelles
  `date`-Attribut im `<tv>`-Root hat. TiviMate cached EPG-Daten teils lokal —
  EPG-Quelle in den Einstellungen ggf. einmal entfernen und neu hinzufügen,
  wenn nach mehreren Stunden noch keine Änderung sichtbar ist.
- **GitHub Actions schlägt fehl**: Unter dem Tab **Actions** auf den
  fehlgeschlagenen Lauf klicken → Logs zeigen, welche Quelle(n) das Problem
  verursachen (der Job selbst schlägt nur fehl, wenn *alle* Quellen
  gleichzeitig down sind).
