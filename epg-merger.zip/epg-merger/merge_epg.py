#!/usr/bin/env python3
"""
merge_epg.py
============
Laedt mehrere XMLTV-EPG-Quellen herunter, dedupliziert Kanaele und Sendungen,
normalisiert alle Zeiten auf UTC und schreibt eine einzelne, valide,
gzip-komprimierte XMLTV-Datei.

Robust gegen einzelne fehlerhafte/nicht erreichbare Quellen: ein Fehler bei
einer Quelle bricht den Gesamtprozess nicht ab, sondern wird geloggt und
uebersprungen.

Nutzung:
    python merge_epg.py --config sources.json --output epg/merged_epg.xml.gz

Exit-Code:
    0  = Erfolg, mindestens eine Quelle konnte verarbeitet werden
    1  = Kritischer Fehler (z.B. keine einzige Quelle erfolgreich, Config kaputt)
"""

from __future__ import annotations

import argparse
import gzip
import io
import json
import logging
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import requests
from lxml import etree

# --------------------------------------------------------------------------
# Logging
# --------------------------------------------------------------------------

logger = logging.getLogger("merge_epg")


def setup_logging(log_file: Optional[Path]) -> None:
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)s] %(message)s", datefmt="%Y-%m-%d %H:%M:%S"
    )
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(fmt)
    logger.addHandler(console)
    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_file, encoding="utf-8")
        fh.setFormatter(fmt)
        logger.addHandler(fh)


# --------------------------------------------------------------------------
# Download & Parsing
# --------------------------------------------------------------------------

HTTP_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/124.0.0.0 Safari/537.36 EPG-Merger/1.0"
    ),
    "Accept": "*/*",
}

GZIP_MAGIC = b"\x1f\x8b"


def download_source(url: str, timeout: int = 60, retries: int = 3) -> bytes:
    """Laedt eine URL herunter, mit Retries. Wirft bei endgueltigem Fehlschlag."""
    last_exc: Optional[Exception] = None
    for attempt in range(1, retries + 1):
        try:
            resp = requests.get(
                url, headers=HTTP_HEADERS, timeout=timeout, stream=True
            )
            resp.raise_for_status()
            data = resp.content
            if not data:
                raise ValueError("Leere Antwort erhalten")
            return data
        except Exception as exc:  # noqa: BLE001 - bewusst breit, pro Quelle robust
            last_exc = exc
            logger.warning(
                "  Versuch %d/%d fuer %s fehlgeschlagen: %s", attempt, retries, url, exc
            )
            if attempt < retries:
                time.sleep(2 * attempt)
    assert last_exc is not None
    raise last_exc


def decompress_if_needed(data: bytes) -> bytes:
    """Erkennt Gzip anhand der Magic Bytes, unabhaengig von der Dateiendung."""
    if data[:2] == GZIP_MAGIC:
        try:
            return gzip.decompress(data)
        except OSError as exc:
            raise ValueError(f"Gzip-Dekompression fehlgeschlagen: {exc}") from exc
    return data


def parse_xml(data: bytes) -> etree._Element:
    """Parst XML fehlertolerant (recover=True ueberspringt kaputte Fragmente)."""
    parser = etree.XMLParser(
        recover=True, resolve_entities=False, huge_tree=True, no_network=True
    )
    root = etree.fromstring(data, parser=parser)
    if root is None:
        raise ValueError("XML konnte nicht geparst werden (root ist None)")
    return root


# --------------------------------------------------------------------------
# Zeit-Normalisierung
# --------------------------------------------------------------------------

# XMLTV-Zeitformat: "YYYYMMDDHHMMSS [+-]HHMM" oder ohne Offset
_TIME_RE = re.compile(
    r"^\s*(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\s*([+-]\d{4})?\s*$"
)


def parse_xmltv_time(value: str) -> Optional[datetime]:
    """Parst eine XMLTV-Zeitangabe zu einem UTC-aware datetime."""
    if not value:
        return None
    m = _TIME_RE.match(value)
    if not m:
        return None
    year, mon, day, hh, mm, ss, off = m.groups()
    try:
        dt = datetime(int(year), int(mon), int(day), int(hh), int(mm), int(ss))
    except ValueError:
        return None
    if off:
        sign = 1 if off[0] == "+" else -1
        off_h, off_m = int(off[1:3]), int(off[3:5])
        delta_minutes = sign * (off_h * 60 + off_m)
        dt = dt.replace(tzinfo=timezone.utc) - __import__("datetime").timedelta(
            minutes=delta_minutes
        )
    else:
        # Keine Zeitzone angegeben -> wir nehmen an, die Quelle liefert bereits UTC.
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def format_xmltv_time(dt: datetime) -> str:
    return dt.strftime("%Y%m%d%H%M%S +0000")


# --------------------------------------------------------------------------
# Datenmodell
# --------------------------------------------------------------------------


def normalize_name(name: str) -> str:
    """Normalisiert einen Kanalnamen fuer den Vergleich (Dedupe-Key)."""
    name = name.lower().strip()
    name = re.sub(r"\(.*?\)", "", name)  # z.B. "(HD)", "(DE)" entfernen
    name = re.sub(r"\b(hd|fhd|uhd|4k|sd|hevc)\b", "", name)
    name = re.sub(r"[^a-z0-9]+", "", name)
    return name


class ChannelInfo:
    __slots__ = ("orig_id", "source", "display_names", "icon", "elem", "programme_count")

    def __init__(self, orig_id: str, source: str, elem: etree._Element):
        self.orig_id = orig_id
        self.source = source
        self.elem = elem
        self.display_names: list[str] = []
        self.icon: Optional[str] = None
        self.programme_count = 0
        for dn in elem.findall("display-name"):
            if dn.text and dn.text.strip():
                self.display_names.append(dn.text.strip())
        icon_el = elem.find("icon")
        if icon_el is not None:
            self.icon = icon_el.get("src")


# --------------------------------------------------------------------------
# Merge-Logik
# --------------------------------------------------------------------------


def load_config(path: Path) -> list[dict]:
    raw = json.loads(path.read_text(encoding="utf-8"))
    sources = raw["sources"] if isinstance(raw, dict) else raw
    if not sources:
        raise ValueError("Keine Quellen in der Konfiguration gefunden")
    return sources


def fetch_and_parse_source(src: dict) -> Optional[etree._Element]:
    name, url = src["name"], src["url"]
    logger.info("Verarbeite Quelle '%s': %s", name, url)
    try:
        raw = download_source(url)
        xml_bytes = decompress_if_needed(raw)
        root = parse_xml(xml_bytes)
        n_ch = len(root.findall("channel"))
        n_pr = len(root.findall("programme"))
        logger.info("  OK: %d Kanaele, %d Sendungen", n_ch, n_pr)
        return root
    except Exception as exc:  # noqa: BLE001
        logger.error("  UEBERSPRUNGEN wegen Fehler: %s", exc)
        return None


def merge_sources(sources_cfg: list[dict]) -> tuple[etree._Element, dict]:
    """Kernprozess: laedt alle Quellen und baut einen zusammengefuehrten <tv>-Baum."""
    all_channels: list[ChannelInfo] = []
    # programme-Elemente je (source_name, orig_channel_id) sammeln
    programmes_by_source_channel: dict[tuple[str, str], list[etree._Element]] = {}
    ok_sources = 0

    for src in sources_cfg:
        root = fetch_and_parse_source(src)
        if root is None:
            continue
        ok_sources += 1
        name = src["name"]
        for ch_elem in root.findall("channel"):
            cid = ch_elem.get("id")
            if not cid:
                continue
            info = ChannelInfo(cid, name, ch_elem)
            all_channels.append(info)
        for pr_elem in root.findall("programme"):
            cid = pr_elem.get("channel")
            title_el = pr_elem.find("title")
            start = pr_elem.get("start")
            if not cid or title_el is None or not (title_el.text or "").strip() or not start:
                continue  # ungueltiger/unvollstaendiger Eintrag -> verwerfen
            key = (name, cid)
            programmes_by_source_channel.setdefault(key, []).append(pr_elem)

    if ok_sources == 0:
        raise RuntimeError("Keine einzige Quelle konnte erfolgreich geladen werden")

    # Sendungsanzahl je Kanal (fuer Dedupe-Priorisierung) zaehlen
    for (src_name, cid), progs in programmes_by_source_channel.items():
        for ch in all_channels:
            if ch.source == src_name and ch.orig_id == cid:
                ch.programme_count += len(progs)

    # --- Kanaele nach normalisiertem Namen gruppieren, Kanonical-ID waehlen ---
    groups: dict[str, list[ChannelInfo]] = {}
    for ch in all_channels:
        key = None
        for dn in ch.display_names:
            norm = normalize_name(dn)
            if norm:
                key = norm
                break
        if not key:
            key = f"__id__{normalize_name(ch.orig_id)}"
        groups.setdefault(key, []).append(ch)

    # (source, orig_id) -> kanonische Ziel-ID
    id_remap: dict[tuple[str, str], str] = {}
    canonical_channels: dict[str, ChannelInfo] = {}

    for group in groups.values():
        # Kanal mit den meisten Sendungen gewinnt als "kanonisch" (Tie-Break: priority, dann Reihenfolge)
        priority_map = {s["name"]: s.get("priority", 0) for s in sources_cfg}
        best = max(
            group,
            key=lambda c: (c.programme_count, priority_map.get(c.source, 0)),
        )
        canonical_id = best.orig_id
        # Falls diese ID bereits von einer ANDEREN Gruppe belegt ist, eindeutig machen
        if canonical_id in canonical_channels and canonical_channels[canonical_id] is not best:
            canonical_id = f"{canonical_id}.{normalize_name(best.source)}"
        canonical_channels[canonical_id] = best
        for ch in group:
            id_remap[(ch.source, ch.orig_id)] = canonical_id
        # Display-Names & Icon ueber die ganze Gruppe zusammenfuehren
        merged_names: list[str] = []
        icon = None
        for ch in sorted(group, key=lambda c: -c.programme_count):
            for dn in ch.display_names:
                if dn not in merged_names:
                    merged_names.append(dn)
            if icon is None and ch.icon:
                icon = ch.icon
        best.display_names = merged_names or best.display_names
        best.icon = icon or best.icon

    # --- Output-Baum aufbauen ---
    out_root = etree.Element("tv")
    out_root.set("generator-info-name", "epg-merger")
    out_root.set("generator-info-url", "https://github.com/")
    out_root.set("date", datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S +0000"))

    for cid, ch in sorted(canonical_channels.items()):
        ch_el = etree.SubElement(out_root, "channel")
        ch_el.set("id", cid)
        for dn in ch.display_names[:5] or [cid]:
            dn_el = etree.SubElement(ch_el, "display-name")
            dn_el.text = dn
        if ch.icon:
            icon_el = etree.SubElement(ch_el, "icon")
            icon_el.set("src", ch.icon)

    # --- Sendungen remappen, normalisieren, deduplizieren, schreiben ---
    # Dedupe-Key: (kanonische Kanal-ID, Start-UTC, normalisierter Titel)
    seen: dict[tuple[str, str, str], etree._Element] = {}
    dropped_orphan = 0
    dropped_badtime = 0

    for (src_name, orig_cid), progs in programmes_by_source_channel.items():
        canonical_id = id_remap.get((src_name, orig_cid))
        if canonical_id is None or canonical_id not in canonical_channels:
            dropped_orphan += len(progs)
            continue
        for pr in progs:
            start_dt = parse_xmltv_time(pr.get("start", ""))
            if start_dt is None:
                dropped_badtime += 1
                continue
            stop_raw = pr.get("stop")
            stop_dt = parse_xmltv_time(stop_raw) if stop_raw else None

            title_el = pr.find("title")
            title_txt = (title_el.text or "").strip()
            dedupe_key = (canonical_id, start_dt.isoformat(), normalize_name(title_txt))

            # Reichhaltigkeit grob ueber Textlaenge aller Kindelemente schaetzen
            richness = sum(len((c.text or "")) for c in pr.iter() if c.text)

            existing = seen.get(dedupe_key)
            if existing is not None:
                existing_richness = int(existing.get("_richness", "0"))
                if richness <= existing_richness:
                    continue  # bestehender Eintrag ist mindestens so gut -> ueberspringen

            new_pr = etree.Element("programme")
            new_pr.set("start", format_xmltv_time(start_dt))
            if stop_dt:
                new_pr.set("stop", format_xmltv_time(stop_dt))
            new_pr.set("channel", canonical_id)
            new_pr.set("_richness", str(richness))  # intern, wird vor Ausgabe entfernt
            for child in pr:
                if child.tag in ("title", "sub-title", "desc", "category", "icon",
                                  "episode-num", "rating", "credits", "date",
                                  "country", "previously-shown", "star-rating",
                                  "audio", "video", "language"):
                    new_pr.append(child)
            seen[dedupe_key] = new_pr

    for pr_el in seen.values():
        del pr_el.attrib["_richness"]
        out_root.append(pr_el)

    stats = {
        "sources_total": len(sources_cfg),
        "sources_ok": ok_sources,
        "channels_out": len(canonical_channels),
        "programmes_out": len(seen),
        "dropped_orphan_programmes": dropped_orphan,
        "dropped_invalid_time": dropped_badtime,
    }
    return out_root, stats


# --------------------------------------------------------------------------
# Schreiben
# --------------------------------------------------------------------------


def write_output(root: etree._Element, output_path: Path, also_plain: bool = True) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    xml_bytes = etree.tostring(
        root, xml_declaration=True, encoding="UTF-8", pretty_print=False
    )

    # Immer als .xml.gz schreiben (unabhaengig von der angegebenen Endung)
    if output_path.suffixes[-2:] == [".xml", ".gz"] or output_path.suffix == ".gz":
        gz_path = output_path
    else:
        gz_path = output_path.with_suffix(output_path.suffix + ".gz")

    buf = io.BytesIO()
    with gzip.GzipFile(fileobj=buf, mode="wb", mtime=0) as gz:
        gz.write(xml_bytes)
    gz_path.write_bytes(buf.getvalue())
    logger.info("Geschrieben: %s (%.1f KB, gzip)", gz_path, gz_path.stat().st_size / 1024)

    if also_plain:
        plain_path = gz_path.with_suffix("").with_suffix(".xml") if gz_path.suffix == ".gz" else gz_path
        plain_path = gz_path.parent / (gz_path.name[:-3] if gz_path.name.endswith(".gz") else gz_path.name)
        plain_path.write_bytes(xml_bytes)
        logger.info("Geschrieben: %s (%.1f KB, unkomprimiert)", plain_path, plain_path.stat().st_size / 1024)


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------


def main() -> int:
    ap = argparse.ArgumentParser(description="Merged mehrere XMLTV-EPG-Quellen zu einer Datei.")
    ap.add_argument("--config", type=Path, default=Path("sources.json"))
    ap.add_argument("--output", type=Path, default=Path("epg/merged_epg.xml.gz"))
    ap.add_argument("--log-file", type=Path, default=Path("epg/merge.log"))
    ap.add_argument("--no-plain", action="store_true", help="Keine unkomprimierte .xml zusaetzlich schreiben")
    args = ap.parse_args()

    setup_logging(args.log_file)
    logger.info("=== EPG-Merge gestartet ===")

    try:
        sources_cfg = load_config(args.config)
    except Exception as exc:
        logger.critical("Konnte Konfiguration nicht laden: %s", exc)
        return 1

    try:
        merged_root, stats = merge_sources(sources_cfg)
    except Exception as exc:
        logger.critical("Merge fehlgeschlagen: %s", exc)
        return 1

    write_output(merged_root, args.output, also_plain=not args.no_plain)

    logger.info(
        "Fertig. Quellen: %d/%d ok | Kanaele: %d | Sendungen: %d | "
        "verworfen (verwaist): %d | verworfen (ungueltige Zeit): %d",
        stats["sources_ok"], stats["sources_total"], stats["channels_out"],
        stats["programmes_out"], stats["dropped_orphan_programmes"],
        stats["dropped_invalid_time"],
    )
    logger.info("=== EPG-Merge beendet ===")
    return 0


if __name__ == "__main__":
    sys.exit(main())
